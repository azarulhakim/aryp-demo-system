import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const ROLES = new Set(["FRANCHISOR_SUPERVISOR", "BRANCH_MANAGER", "EXECUTIVE", "TELLER", "VAULT_CUSTODIAN", "AUDITOR"]);
const PRIVILEGED = new Set(["FRANCHISOR_SUPERVISOR", "AUDITOR"]);
const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const authKey = Deno.env.get("SUPABASE_ANON_KEY") || serviceKey;

const headers = { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", "x-content-type-options": "nosniff", "referrer-policy": "no-referrer" };
const response = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers });

async function db(table: string, query = "", options: { method?: string; body?: unknown; prefer?: string } = {}) {
  const result = await fetch(`${supabaseUrl}/rest/v1/${table}${query}`, {
    method: options.method || "GET",
    headers: { apikey: serviceKey, authorization: `Bearer ${serviceKey}`, "content-type": "application/json", prefer: options.prefer || "return=representation" },
    body: options.body === undefined ? undefined : JSON.stringify(options.body),
  });
  const text = await result.text();
  let data: any = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = { message: text }; }
  if (!result.ok) throw new Error(data?.message || `supabase_${result.status}`);
  return data;
}

async function authUser(request: Request) {
  const token = request.headers.get("authorization") || "";
  if (!token.startsWith("Bearer ")) return null;
  const result = await fetch(`${supabaseUrl}/auth/v1/user`, { headers: { apikey: authKey, authorization: token } });
  return result.ok ? result.json() : null;
}

async function context(request: Request) {
  const user = await authUser(request);
  if (!user?.id) return null;
  const rows = await db("aryp_memberships", `?select=user_id,role,branch_ids,enabled&user_id=eq.${encodeURIComponent(user.id)}&enabled=eq.true&limit=1`);
  const member = rows?.[0];
  return member && ROLES.has(member.role) ? { user, member } : null;
}

function canSee(member: any, branchId: string) { return PRIVILEGED.has(member.role) || (member.branch_ids || []).includes(branchId); }
function can(member: any, roles: string[]) { return roles.includes(member.role); }
function correlation(request: Request) { const id = request.headers.get("x-correlation-id") || ""; return /^[A-Za-z0-9._:-]{1,96}$/.test(id) ? id : `COR-${crypto.randomUUID()}`; }

async function seed() { const rows = await db("aryp_demo_seed", "?select=payload&dataset_id=eq.ARYP-DEMO-SEED-001&limit=1"); return rows?.[0]?.payload || { meta: {}, branches: [], customers: [], pledges: [] }; }
async function state() { const rows = await db("aryp_demo_state", "?select=*&id=eq.DEMO&limit=1"); return rows?.[0]; }
async function patchState(values: Record<string, unknown>) { const rows = await db("aryp_demo_state", "?id=eq.DEMO", { method: "PATCH", body: { ...values, updated_at: new Date().toISOString() } }); return rows?.[0]; }
async function audit(request: Request, ctx: any, action: string, result: string, detail: Record<string, unknown> = {}, branchId = "BR-001") { await db("aryp_audit_events", "", { method: "POST", body: { correlation_id: correlation(request), actor_user_id: ctx.user.id, actor_role: ctx.member.role, branch_id: branchId, action, result, detail, state: "SIMULATION" } }); }
async function auditRows(ctx: any) { const rows = await db("aryp_audit_events", "?select=*&order=created_at.desc&limit=30"); return (rows || []).filter((event: any) => canSee(ctx.member, event.branch_id)).reverse(); }
function history(payload: any, customerId: string) {
  const customer = (payload.customers || []).find((item: any) => item.id === customerId); if (!customer) return [];
  const result = (payload.pledges || []).filter((item: any) => item.customer_id === customerId).map((item: any) => ({ label: `${item.state === "OVERDUE" ? "Gadaian tertunggak" : "Gadaian aktif"} · RM${Number(item.simulated_financing).toLocaleString("ms-MY", { minimumFractionDigits: 2 })}`, detail: `${item.id} · ${item.branch_id}`, state: item.state }));
  if (customer.risk_state === "REPEAT_REVIEW") result.push({ label: "Semakan repeat customer diperlukan", detail: "Fixture risk · polisi provisional", state: "REPEAT_REVIEW" });
  if (customer.risk_state === "BLACKLIST_REVIEW") result.push({ label: "Risk hold · BLACKLIST_REVIEW", detail: "Tiada bypass dibenarkan", state: "BLACKLIST_REVIEW" });
  return result;
}
async function snapshot(ctx: any) {
  const [payload, demo, auditEvents] = await Promise.all([seed(), state(), auditRows(ctx)]);
  return { meta: payload.meta, demo: { role: ctx.member.role, pledge: demo.pledge_state, cashBalance: Number(demo.cash_balance), customerFixture: demo.customer_fixture, customerRisk: demo.customer_risk, customerReview: demo.customer_review, customerHistory: demo.customer_history || [], vault: demo.vault_state, vaultAcceptance: demo.vault_acceptance || {}, auction: demo.auction_state, reportPath: demo.report_path, dayEnd: demo.day_end, completion: demo.completion }, actor: ctx.member.role, counts: { customers: (payload.customers || []).length, pledges: (payload.pledges || []).length, branches: (payload.branches || []).length }, audit: auditEvents };
}

async function action(request: Request, ctx: any, input: any) {
  const payload = await seed(); const demo = await state(); const name = input.action;
  const customer = (id: string) => (payload.customers || []).find((item: any) => item.id === id);
  const pledge = (id: string) => (payload.pledges || []).find((item: any) => item.id === id);
  const fail = async (status: number, error: string, detail: Record<string, unknown> = {}, branch = "BR-001") => { await audit(request, ctx, name, "DENIED", { reason: error, ...detail }, branch); return response({ error, ...(await snapshot(ctx)) }, status); };
  const ok = async (detail: Record<string, unknown> = {}, branch = "BR-001") => { await audit(request, ctx, name, "ALLOWED", detail, branch); return response(await snapshot(ctx)); };
  if (name === "reset_demo") { await patchState({ pledge_state: "PENDING_SIGNATURE", cash_balance: 37580, customer_fixture: "CUS-001", customer_risk: "CLEAR", customer_review: "NONE", customer_history: [], vault_state: "PENDING", vault_acceptance: {}, auction_state: "READY", report_path: "FR-001", day_end: "OPEN", completion: "PENDING" }); return ok({ reset: true }); }
  if (name === "load_customer") { const item = customer(input.customerId); if (!item) return fail(404, "customer_not_found"); if (!canSee(ctx.member, item.branch_id)) return fail(403, "tenant_boundary", { customer_id: item.id }, item.branch_id); await patchState({ customer_fixture: item.id, customer_risk: item.risk_state, customer_review: "NONE", customer_history: history(payload, item.id) }); return ok({ customer_id: item.id, risk_state: item.risk_state }, item.branch_id); }
  if (name === "risk_review") { if (!can(ctx.member, ["BRANCH_MANAGER", "FRANCHISOR_SUPERVISOR"])) return fail(403, "risk_reviewer_role_required"); const item = customer(input.customerId || demo.customer_fixture); if (!item) return fail(404, "customer_not_found"); if (!canSee(ctx.member, item.branch_id)) return fail(403, "tenant_boundary", { customer_id: item.id }, item.branch_id); await patchState({ customer_fixture: item.id, customer_risk: item.risk_state, customer_history: history(payload, item.id) }); if (item.risk_state === "BLACKLIST_REVIEW") return fail(409, "blacklist_hold", { customer_id: item.id }, item.branch_id); await patchState({ customer_review: "REVIEWED_SIMULATED" }); return ok({ customer_id: item.id, risk_state: item.risk_state }, item.branch_id); }
  if (name === "approve_pledge" || name === "reject_pledge") { if (!can(ctx.member, ["BRANCH_MANAGER", "FRANCHISOR_SUPERVISOR"])) return fail(403, "maker_checker_required"); const item = pledge(input.pledgeId || "PLG-001"); if (!item) return fail(404, "pledge_not_found"); if (!canSee(ctx.member, item.branch_id)) return fail(403, "tenant_boundary", { pledge_id: item.id }, item.branch_id); await patchState({ pledge_state: name === "approve_pledge" ? "APPROVED" : "REJECTED" }); return ok({ pledge_id: item.id, reason: input.reason || null }, item.branch_id); }
  if (name === "cash_out") { if (!can(ctx.member, ["TELLER", "BRANCH_MANAGER", "EXECUTIVE", "FRANCHISOR_SUPERVISOR"])) return fail(403, "cashier_role_required"); const amount = Number(input.amount || 2730); if (!Number.isFinite(amount) || amount <= 0 || amount > 100000) return fail(400, "invalid_amount"); if (demo.pledge_state !== "APPROVED") return fail(409, "approval_required"); await patchState({ pledge_state: "CASH_OUT_SIMULATED", cash_balance: Number(demo.cash_balance) - amount }); return ok({ amount }); }
  if (name === "vault_checkin") { if (!can(ctx.member, ["VAULT_CUSTODIAN", "BRANCH_MANAGER", "FRANCHISOR_SUPERVISOR"])) return fail(403, "vault_role_required"); if (demo.pledge_state !== "CASH_OUT_SIMULATED") return fail(409, "cash_out_required"); await patchState({ vault_state: "CHECKED_IN_SIMULATED", pledge_state: "PLEDGED_ACTIVE" }); return ok({ pledge_id: input.pledgeId || "PLG-001", location: "VAULT-A-01" }); }
  if (name === "vault_accept") { if (!can(ctx.member, ["VAULT_CUSTODIAN", "BRANCH_MANAGER", "FRANCHISOR_SUPERVISOR"])) return fail(403, "vault_role_required"); const ref = String(input.reference || ""); if (!["0041", "0042"].includes(ref)) return fail(404, "unknown_vault_bag"); await patchState({ vault_acceptance: { ...(demo.vault_acceptance || {}), [ref]: "ACCEPTED_SIMULATED" } }); return ok({ reference: ref, location: ref === "0042" ? "VAULT-A-03-B12" : "VAULT-A-01" }); }
  if (name === "redemption") { if (!can(ctx.member, ["TELLER", "BRANCH_MANAGER", "EXECUTIVE", "FRANCHISOR_SUPERVISOR"])) return fail(403, "cashier_role_required"); await patchState({ pledge_state: "REDEMPTION_SIMULATED" }); return ok({ pledge_id: input.pledgeId || "PLG-002", provider: "MOCK_PAYMENT" }); }
  if (name === "complete_pledge") { if (!can(ctx.member, ["BRANCH_MANAGER", "EXECUTIVE", "FRANCHISOR_SUPERVISOR"])) return fail(403, "completion_role_required"); if (demo.pledge_state !== "PLEDGED_ACTIVE") return fail(409, "vault_checkin_required"); await patchState({ completion: "COMPLETED_SIMULATED" }); return ok({ pledge_id: input.pledgeId || "PLG-001" }); }
  if (name === "stocktake") { if (!can(ctx.member, ["VAULT_CUSTODIAN", "BRANCH_MANAGER", "AUDITOR", "FRANCHISOR_SUPERVISOR"])) return fail(403, "stocktake_role_required"); await patchState({ vault_state: "STOCKTAKE_MATCHED" }); return ok({ matched: 4, variance: 0 }); }
  if (name === "vault_no_dual") return fail(403, "dual_control_required");
  if (name === "close_day") { if (!can(ctx.member, ["TELLER", "BRANCH_MANAGER", "EXECUTIVE", "FRANCHISOR_SUPERVISOR"])) return fail(403, "day_end_role_required"); const variance = Number(input.variance || 0); if (!input.checklist || !Number.isFinite(variance) || Math.abs(variance) >= 0.005) return fail(409, "day_end_checklist_or_variance", { variance }); await patchState({ day_end: "CLOSED_SIMULATED" }); return ok({ variance, checklist: true }); }
  if (name === "auction_overdue") { if (!can(ctx.member, ["BRANCH_MANAGER", "EXECUTIVE", "FRANCHISOR_SUPERVISOR"])) return fail(403, "auction_role_required"); await patchState({ auction_state: "OVERDUE_SIMULATED" }); return ok({ pledge_id: "PLG-003" }); }
  if (name === "auction_result") { if (!can(ctx.member, ["BRANCH_MANAGER", "EXECUTIVE", "FRANCHISOR_SUPERVISOR"])) return fail(403, "auction_role_required"); if (!["surplus", "shortfall"].includes(input.result)) return fail(400, "invalid_result"); await patchState({ auction_state: input.result === "shortfall" ? "SHORTFALL_REVIEW_SIMULATED" : "SURPLUS_SIMULATED" }); return ok({ result: input.result }); }
  if (name === "tenant_probe") return fail(403, "tenant_boundary", { target_branch: "BR-999" });
  if (name === "drilldown") { if (!can(ctx.member, ["AUDITOR", "FRANCHISOR_SUPERVISOR", "EXECUTIVE", "BRANCH_MANAGER"])) return fail(403, "report_role_required"); await patchState({ report_path: String(input.target || "PLG-001").slice(0, 64) }); return ok({ target: input.target || "PLG-001" }); }
  return response({ error: "unknown_action" }, 400);
}

Deno.serve(async (request) => {
  const path = new URL(request.url).pathname.replace(/^\/functions\/v1\/aryp-api/, "") || "/";
  if (path === "/health") return response({ ok: true, service: "aryp-api", dataset: "ARYP-DEMO-SEED-001", status: "SYNTHETIC_ONLY" });
  const ctx = await context(request);
  if (!ctx) return response({ error: "membership_required" }, 403);
  try {
    if (request.method === "GET" && path === "/session") return response(await snapshot(ctx));
    if (request.method === "GET" && path === "/customers") { const payload = await seed(); return response({ items: (payload.customers || []).filter((item: any) => canSee(ctx.member, item.branch_id)) }); }
    if (request.method === "GET" && path === "/pledges") { const payload = await seed(); return response({ items: (payload.pledges || []).filter((item: any) => canSee(ctx.member, item.branch_id)) }); }
    if (request.method === "GET" && path === "/audit") return response({ items: await auditRows(ctx) });
    if (request.method === "POST" && path === "/actions") { const length = Number(request.headers.get("content-length") || 0); if (length > 32768) return response({ error: "payload_too_large" }, 413); let input: any; try { input = await request.json(); } catch { return response({ error: "invalid_json" }, 400); } if (!input || typeof input !== "object" || Array.isArray(input)) return response({ error: "invalid_payload" }, 400); return await action(request, ctx, input); }
    return response({ error: "not_found" }, 404);
  } catch (error) { console.error(error); return response({ error: "internal_error" }, 500); }
});
