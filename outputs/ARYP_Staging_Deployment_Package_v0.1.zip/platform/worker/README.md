# ARYP Cloudflare Worker — Staging

This is the authenticated staging boundary for the ARYP synthetic demo. It is separate from the local `app/` demo and does not enable real money movement, official calculations, live providers, or production data.

## Configure

1. Apply the migration in `supabase/migrations/` to the ARYP staging Supabase project.
2. The Supabase Edge Function `aryp-api` owns the service-role boundary; the service-role key is never placed in Cloudflare or browser code.
3. Set the Supabase publishable key as the `SUPABASE_PUBLISHABLE_KEY` Worker variable for staging.
4. Create staging Auth users and add their UUIDs to `public.aryp_memberships` using the role/branch template in `supabase/README.md`.
5. Validate without publishing:

```text
npm install
npm run check
npm run dev
```

6. Deploy only the staging environment:

```text
npm run deploy:staging
```

## Current staging deployment

The deployed synthetic staging URL is:

`https://aryp-staging.ariavibecoderlab.workers.dev`

Open the URL, create a staging Auth account, then add that account's UUID to `public.aryp_memberships` before using the mockup. The account email may be shared with the project operator for onboarding; never share the password.

Example membership insert (run only by an authorised project operator through Supabase SQL):

```sql
insert into public.aryp_memberships (user_id, role, branch_ids)
values ('AUTH_USER_UUID', 'BRANCH_MANAGER', array['BR-001']::text[]);
```

The client UI remains synthetic-only. The Worker health endpoint is public for monitoring; all other API calls require a Supabase access token and a membership row.

The production-named synthetic demo endpoint is available at `https://aryp-production.ariavibecoderlab.workers.dev`. It still points to the dedicated synthetic Supabase project and is not a production release. Real production secrets, domain routes, PII and money movement remain disabled until the client gates and UAT are approved.
