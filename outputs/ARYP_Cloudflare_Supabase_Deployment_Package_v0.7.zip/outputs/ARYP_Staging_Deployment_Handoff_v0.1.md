# ARYP Staging Deployment Handoff v0.1

**Tarikh:** 2026-08-17  
**Status:** LIVE — synthetic staging and production-named demo endpoint  
**Production release:** blocked by approval gates

## Pautan

- Staging UI (akaun Cloudflare betul): https://aryp-staging.rsshost.workers.dev
- Default production-named demo URL (akaun Cloudflare betul): https://aryp-production.rsshost.workers.dev
- Supabase project URL: https://ywfmbygeximvrbfniify.supabase.co
- Supabase project ref: `ywfmbygeximvrbfniify`

## Apa yang sudah aktif

- Cloudflare Worker staging dengan security headers dan static mockup.
- Supabase Auth shell; API calls require bearer token.
- Supabase Edge Function `aryp-api`, deployed with JWT verification.
- Synthetic seed, shared demo state, memberships and audit tables.
- RLS enabled with explicit deny policies for direct client access.
- No real PII, money movement, marhun, live provider or production secret.
- Cloudflare account target: `1a31137d59cff2a0b541cdcd28600bc8` (`Azarulhakim20@gmail.com` account).
- Formula/maker-checker demo: active formula `FINANCING_DEFAULT / ASSUMED-CALC-0.1` is configurable and versioned; `quote_financing`, `submit_pledge`, approval and rejection are enforced server-side. A maker cannot approve the same pledge. All values remain simulation-only and `ASSUMED—NOT APPROVED`.
- Data lifecycle demo: active policy `DATA_LIFECYCLE_DEFAULT / ASSUMED-RETENTION-0.1` keeps retention duration unset (`PENDING_CLIENT`), disables deletion in demo, and supports audited legal holds. An active hold blocks redemption, cash-out and auction simulation; only authorized manager/franchisor roles can release it.
- Privacy demo: active policy `PRIVACY_DEFAULT / ASSUMED-PRIVACY-0.1` exposes a draft notice, unset legal basis/consent requirement, configurable DSR hooks and disabled erasure. Consent capture/withdrawal and ACCESS, RECTIFICATION, ERASURE or RESTRICTION requests are simulated and audited.
- Regulatory demo: seven neutral versioned rule placeholders are available to privileged roles through `/api/regulatory-rules`; all remain `CLIENT_TO_CONFIRM` / `PENDING_CLIENT` with evidence and conflict-handling metadata. The system does not claim statutory applicability.
- NFR demo: six versioned target registries are available through `/api/nfr-targets`; latency, volume, uptime, RTO/RPO and log-retention numbers remain unset. WCAG 2.2 AA is a working target only. `/api/actions` supports audited simulated NFR observations with `PENDING_CLIENT` acceptance.
- Hosting/region assumption: `/api/deployment-info` records Cloudflare Workers + Supabase as the current synthetic stack. Region, residency, cross-border, subprocessors and production approval are explicitly `PENDING_CLIENT` / unverified.
- Autonomous assumption register: `outputs/ARYP_Autonomous_Assumption_Register_v0.1.md` records reversible defaults for all 226 requirements. High-risk items remain labelled `ASSUMED—NOT APPROVED` and cannot authorize production use.
- Release gates: `/api/release-gates` exposes G1–G12 with required evidence/sign-offs. Every gate currently starts as `PENDING`; a production transition cannot be inferred from demo activity.
- Governance console: after login, use `Polisi & gates` in the top bar or open `/governance.html` to review active policies, regulatory/NFR registries and G1–G12 status. Document and heir rows include simulated review buttons; API role/evidence checks still apply.
- Organization scope: the normalized assumption hierarchy is `ARYP franchisor → three franchisees → six branches → user memberships/roles`. Franchisor Supervisor and Auditor see the network; organization assignments inherit their franchisee branches; branch assignments see only their assigned branch. The Governance Console now displays the visible organization tree and scope.
- Client user manual: `outputs/ARYP_Manual_Pengguna_Staging_v0.1.docx`, `outputs/ARYP_Manual_Pengguna_Staging_v0.1.pdf` and the shareable bundle `outputs/ARYP_Manual_Pengguna_Staging_v0.1.zip` document the complete role-by-role test flows with staging screenshots, expected results, reset procedure, troubleshooting and synthetic-data boundaries.
- Registration redirect fix: the staging login shell now sends an explicit `email_redirect_to` equal to the current Worker origin during signup. New confirmation links return to staging; older links already issued with `localhost` must be replaced by requesting a fresh confirmation email.
- Gate review controls: executive, franchisor supervisor and auditor can select `IN_REVIEW`, `PASSED`, `BLOCKED` or `WAIVED`, then record a note and evidence snapshot. `PASSED`/`WAIVED` are rejected without both fields. This is an auditable simulation workflow only; the API always reports `production_release_allowed=false` until real client gates are approved.
- Notification simulation: `/api/notifications` returns branch-scoped synthetic delivery records with masked destinations, status, template version and evidence. `queue_notification` and `retry_notification` validate event/channel/idempotency inputs and use `MOCK_PROVIDER`; raw e-mail addresses are rejected and no SMS/e-mail provider is called. Governance Console includes the notification evidence table.
- Reporting simulation: `/api/reports/summary` returns role-scoped synthetic operations metrics with `SIMULATED_NOW` freshness and `Asia/Kuala_Lumpur` timezone. `export_report` validates CSV/PDF/XLSX requests, applies masked-by-default policy, audits the request and keeps download disabled in demo. Governance Console includes the report summary and export policy.
- Case/exception simulation: `/api/cases` shows synthetic customer-identity, privacy-DSR and integration-failure cases. `open_case` and `resolve_case` are role-checked, validate category/priority/evidence and write audit events; SLA remains `PENDING_CLIENT`. Governance Console includes the case/hold/exception table.
- Valuation/calculation simulation: migration `20260817000011_aryp_valuation_fixtures.sql` adds synthetic 916/999 gold prices and branch-scoped marhun items. `/api/valuation/prices` and `calculate_valuation` expose fixture-only valuation, formula version, 0.01 rounding and calculation snapshot IDs; manual overrides are labelled simulated and every calculation is audited. No live price source is called.
- Ledger/cash/custody simulation: migration `20260817000012_aryp_ledger_cash_fixtures.sql` adds synthetic payments, drawer, ledger, vault, auction and heir fixtures. `/api/finance/summary` exposes masked role-scoped totals; `cash_count` requires a reason for non-zero variance and `bank_in_simulated` requires amount plus slip reference. No bank, ledger or custody provider is called.
- Documents/heirs simulation: migration `20260817000013_aryp_documents_heirs_fixtures.sql` adds versioned synthetic SAG, privacy-consent and auction-notice document records plus branch-scoped heir-claim records. `/api/documents` and `/api/heirs` expose role-scoped registers; `document_review` requires evidence and `heir_claim_review` requires a document reference. Governance Console renders both registers. Signature, document approval and heir decisions are simulated only and carry synthetic classification/watermark.
- Authorization hardening: `aryp-api` v17 limits `reset_demo` to supervisory roles and checks branch visibility for document/heir review actions. Teller reset and cross-branch manager review are rejected with audited tenant/role errors; network auditor review remains available.
- SAG preview: `/sag.html?reference=ARYP-BNG-260815-0042&mode=demo` is available on both endpoints. It is a print-ready A4-landscape draft modelled on the supplied client example, using the extracted AR-Rahnu YaPEIM logo, branch/header metadata, personal-information panel, marhun table, financing summary, lafaz sections and signature/cop spaces. It carries `SAG v3.2`, a synthetic-only watermark, checksum and a `Cetak / Simpan PDF` action. The Gadaian baharu flow's `Cetak label & SAG` button opens this preview in a new tab. It is still a simulated draft, not a client-approved legal/Shariah form.

## Cara akses operator

1. Buka URL staging dan pilih daftar akaun.
2. Sahkan e-mel menggunakan mekanisme Auth yang dikonfigurasi untuk project staging.
3. Beri e-mel akaun kepada project operator (jangan beri password).
4. Operator cari UUID user di `auth.users` dan tambah membership:

```sql
insert into public.aryp_memberships (user_id, role, branch_ids)
values ('AUTH_USER_UUID', 'BRANCH_MANAGER', array['BR-001']::text[]);
```

5. Log masuk semula dan uji flow synthetic: pelanggan, gadaian baharu, kelulusan, tunai simulasi, vault, lelongan, laporan dan audit.

## Akaun demo synthetic

Login page menyediakan butang pantas untuk semua role berikut. Semua akaun menggunakan kata laluan `ARYP-Demo-2026!` dan hanya untuk testing synthetic:

| Role | E-mel |
|---|---|
| BRANCH_MANAGER | `demo.manager@aryp-demo.my` |
| TELLER | `demo.teller@aryp-demo.my` |
| VAULT_CUSTODIAN | `demo.vault@aryp-demo.my` |
| FRANCHISOR_SUPERVISOR | `demo.franchisor@aryp-demo.my` |
| EXECUTIVE | `demo.executive@aryp-demo.my` |
| AUDITOR | `demo.auditor@aryp-demo.my` |

Untuk menukar role, log keluar dan pilih butang role yang lain. Akaun ini tidak boleh digunakan untuk production atau data sebenar.

## Smoke evidence

- Worker `/api/health`: HTTP 200, `SYNTHETIC_ONLY`.
- Worker `/api/session` tanpa token: HTTP 401.
- Edge Function tanpa token: HTTP 401.
- Static shell: HTTP 200.
- SAG preview: staging and production `/sag.html` return HTTP 200 with `text/html`, and `/mockup.html` contains the launcher wiring.
- Local application checks and smoke tests remain passing.
- Latest role smoke: all six demo roles return HTTP 200 from `/api/session`, with 12 release gates, 7 regulatory rules and 6 NFR policies. Documents/heirs endpoints return HTTP 200; evidence validation rejects incomplete document review; manager and teller review actions produce audit events.

## Baki sebelum production

Requirement decisions, approved regulatory/privacy/security rules, real tenancy model, NFR/SLA, backup/restore, monitoring/incident runbook, UAT/pilot, business sign-off, production domain and production secret ownership are still required. Staging assumptions must not be represented as approved policy.
