# ARYP Cloudflare Worker — Staging

This is the authenticated staging boundary for the ARYP synthetic demo. It is separate from the local `app/` demo and does not enable real money movement, official calculations, live providers, or production data.

## Configure

1. Apply the migration in `supabase/migrations/` to the ARYP staging Supabase project.
2. The Supabase Edge Function `aryp-api` owns the service-role boundary; the service-role key is never placed in Cloudflare or browser code.
3. Set the Supabase publishable key as the `SUPABASE_PUBLISHABLE_KEY` Worker variable for staging.
4. Create staging Auth users and add their UUIDs to `public.aryp_memberships` using the role/branch template in `supabase/README.md`.
5. Validate without publishing:

```text
npm install
npm run check
npm run dev
```

6. Deploy only the staging environment:

```text
npm run deploy:staging
```

## Current staging deployment

The deployed synthetic staging URL on the correct Cloudflare account is:

`https://aryp-staging.rsshost.workers.dev`

Open the URL, create a staging Auth account, then add that account's UUID to `public.aryp_memberships` before using the mockup. The account email may be shared with the project operator for onboarding; never share the password.

The login page also contains six pre-created synthetic demo accounts for role testing. Their shared demo password is `ARYP-Demo-2026!`; use the role buttons on the page and log out before switching role.

New account registration sends `email_redirect_to` explicitly to the current Worker origin, so confirmation links from the staging page return to `https://aryp-staging.rsshost.workers.dev/` instead of a local development URL. If an older confirmation email still contains `localhost`, request a fresh confirmation email after refreshing the staging page.

Example membership insert (run only by an authorised project operator through Supabase SQL):

```sql
insert into public.aryp_memberships (user_id, role, branch_ids)
values ('AUTH_USER_UUID', 'BRANCH_MANAGER', array['BR-001']::text[]);
```

The client UI remains synthetic-only. The Worker health endpoint is public for monitoring; all other API calls require a Supabase access token and a membership row.

The production-named synthetic demo endpoint is available at `https://aryp-production.rsshost.workers.dev`. It still points to the dedicated synthetic Supabase project and is not a production release. Real production secrets, domain routes, PII and money movement remain disabled until the client gates and UAT are approved.

After login, use **Polisi & gates** in the top bar or open `/governance.html` to review versioned policies, regulatory/NFR registries and G1–G12 release status. All gates begin as `PENDING`. Executive, franchisor supervisor and auditor roles can record a review status, note and evidence snapshot; `PASSED`/`WAIVED` remain simulation-only and never unlock production.
